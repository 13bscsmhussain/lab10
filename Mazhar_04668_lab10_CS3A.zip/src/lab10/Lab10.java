/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;
import org.hibernate.HibernateException; 
import org.hibernate.Session; 
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import java.nio.file.Files;
import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 *
 * @author test1
 */



public class Lab10 {

    //GUI creating
    public class SwingControlDemo {
    
    private JFrame mainFrame;
    private JLabel headerLabel;
    

    public SwingControlDemo(){
        prepareGUI();
    }
    
    //calling function to create GUI
     private void prepareGUI(){
      mainFrame = new JFrame("GUI");
      mainFrame.setSize(400,400);
      mainFrame.setLayout(new GridLayout(3, 1));
      final JButton Button = new JButton("check ");  
      mainFrame.addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent windowEvent){
            System.exit(0);
            
            
      Button.addActionListener(new ActionListener() {
         public void actionPerformed(ActionEvent e) {
            String path = "D:\\";
          hashfunc(path);
         }          
      });
          
     }
              });
    }
    }
    /**
     * @param args the command line arguments
     */
    
    public Integer addfileObjectPojo(String fileName, String hashValue){
      Session session = factory.openSession();
      Transaction tx = null;
      Integer fileValue = null;
      try{
         tx = session.beginTransaction();
         fileObjectPojo fileObjectPojo2 = new fileObjectPojo(fileName, hashValue);
         fileValue = (Integer) session.save(fileObjectPojo2); 
         tx.commit();
      }catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      }finally {
         session.close(); 
      }
      return fileValue;
   }
    
    //calculating hash values  
    public static void hashfunc(String path){
        //MessageDigest md = null;
        Map mapA = new HashMap();
        
        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();

        for (int i = 0; i < listOfFiles.length; i++) {
            int hashval;
            hashval = listOfFiles[i].hashCode();
            System.out.print(hashval);
            mapA.put(listOfFiles[i].getName(), hashval);
            System.out.print(mapA.get(i));
    }
       // System.out.println(Arrays.toString(digest));
    
    }
    public static void main(String[] args) {
        // TODO code application logic here
        
         
        String path = "D:\\";
        hashfunc(path); 
    }
}