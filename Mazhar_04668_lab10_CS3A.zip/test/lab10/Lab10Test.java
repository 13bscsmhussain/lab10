/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

import java.io.File;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author test1
 */
public class Lab10Test {
    
    public Lab10Test() {
    }
    
    @Test
    public void hashfunc() throws Exception {
        System.out.println("hashvalue");
        File folder = new File("C:\\Users\\sali.bscs13seecs\\Desktop\\directory");
    File[] listOfFiles = folder.listFiles();

        String expResult = "aefjdkafj34343kfjadkf";
        String result = Lab10.hashfunc(listOfFiles[0]);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       
    }


    /**
     * Test of hashfunc method, of class Lab10.
     */
    @Test
    public void testHashfunc() {
        System.out.println("hashfunc");
        String path = "";
        Lab10.hashfunc(path);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Lab10.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Lab10.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
